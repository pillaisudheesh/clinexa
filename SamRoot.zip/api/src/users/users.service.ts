import {
  Injectable,
  ConflictException,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UserResponseDto } from './dto/user-response.dto';
import * as bcrypt from 'bcrypt';
import { UserMapper } from './mappers/user.mapper';
import { UpdateUserDto } from './dto/update-user.dto';
import { UpdateUserStatusDto } from './dto/update-user-status.dto';
import { PaginatedResponseDto } from '../common/dto/paginated-response.dto';
import { UserQueryDto } from './dto/user-query.dto';
import type { AuthenticatedUser } from '../auth/interfaces/authenticated-user.interface';

type UserWithRoles = Prisma.UserGetPayload<{
  include: {
    roles: {
      include: {
        role: true;
      };
    };
  };
}>;

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  private isSuperAdministrator(user: AuthenticatedUser): boolean {
    const values = [...(user.roles ?? []), ...(user.roleCodes ?? [])];
    return values.some((value) =>
      ['SUPER_ADMIN', 'SUPER ADMIN', 'SUPER_ADMINISTRATOR'].includes(
        value.trim().toUpperCase().replace(/[_-]+/g, ' '),
      ),
    );
  }

  private isSuperAdminRoleCode(code: string): boolean {
    return ['SUPER_ADMIN', 'SUPER_ADMINISTRATOR'].includes(
      code.trim().toUpperCase().replace(/[\s-]+/g, '_'),
    );
  }

  async create(
    dto: CreateUserDto,
    requester: AuthenticatedUser,
  ): Promise<UserResponseDto> {
    const isSuperAdmin = this.isSuperAdministrator(requester);
    if (!isSuperAdmin && dto.clinicId !== requester.clinicId) {
      throw new ForbiddenException(
        'You can only create users for your own clinic.',
      );
    }
    // Check duplicate email
    const existingUser = await this.findByEmail(dto.email);

    if (existingUser) {
      throw new ConflictException('Email already exists.');
    }

    // Validate clinic
    const clinic = await this.findClinic(dto.clinicId);

    if (!clinic) {
      throw new NotFoundException('Clinic not found.');
    }

    // Validate roles
    const roles = await this.findRoles(dto.roleIds);

    if (roles.length !== dto.roleIds.length) {
      throw new NotFoundException('One or more roles were not found.');
    }
    if (roles.some((role) => role.clinicId !== dto.clinicId)) {
      throw new ForbiddenException(
        'All assigned roles must belong to the selected clinic.',
      );
    }
    if (
      !isSuperAdmin &&
      roles.some((role) => this.isSuperAdminRoleCode(role.code))
    ) {
      throw new ForbiddenException(
        'Clinic administrators cannot assign the Super Administrator role.',
      );
    }

    // Hash password
    const passwordHash = await bcrypt.hash(dto.password, 10);

    // Create user + assign roles in a transaction
    const createdUser = await this.prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          firstName: dto.firstName,
          lastName: dto.lastName,
          email: dto.email,
          passwordHash,
          clinicId: dto.clinicId,
        },
      });

      await tx.userRole.createMany({
        data: dto.roleIds.map((roleId) => ({
          userId: user.id,
          roleId,
        })),
      });

      const fullUser = await tx.user.findUniqueOrThrow({
        where: {
          id: user.id,
        },
        include: {
          roles: {
            include: {
              role: true,
            },
          },
        },
      });

      return fullUser;
    });

    return UserMapper.toResponseDto(createdUser);
  }

  private async findClinic(clinicId: string) {
    return this.prisma.clinic.findUnique({
      where: { id: clinicId },
    });
  }

  private async findRoles(roleIds: string[]) {
    return this.prisma.role.findMany({
      where: {
        id: {
          in: roleIds,
        },
      },
    });
  }

  // private async findByEmail(email: string) {
  //   return this.prisma.user.findUnique({
  //     where: { email },
  //   });
  // }

  async findAll(
    query: UserQueryDto,
    requester: AuthenticatedUser,
  ): Promise<PaginatedResponseDto<UserResponseDto>> {
    const { page, limit, search, sortBy, sortOrder } = query;

    const skip = (page - 1) * limit;

    const where: Prisma.UserWhereInput = {
      ...(!this.isSuperAdministrator(requester)
        ? { clinicId: requester.clinicId }
        : {}),
      ...(search
        ? {
            OR: [
              {
                firstName: {
                  contains: search,
                  mode: 'insensitive' as const,
                },
              },
              {
                lastName: {
                  contains: search,
                  mode: 'insensitive' as const,
                },
              },
              {
                email: {
                  contains: search,
                  mode: 'insensitive' as const,
                },
              },
            ],
          }
        : {}),
    };

    const [users, total] = await this.prisma.$transaction([
      this.prisma.user.findMany({
        where,
        include: {
          roles: {
            include: {
              role: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: {
          [sortBy]: sortOrder,
        },
      }),

      this.prisma.user.count({
        where,
      }),
    ]);

    return {
      data: users.map((user) => UserMapper.toResponseDto(user)),
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async findByEmail(email: string) {
    return this.prisma.user.findUnique({
      where: {
        email,
      },
    });
  }

  async findById(id: string): Promise<UserWithRoles | null> {
    return this.prisma.user.findUnique({
      where: { id },
      include: {
        roles: {
          include: {
            role: true,
          },
        },
      },
    });
  }

  async update(
    id: string,
    dto: UpdateUserDto,
    requester: AuthenticatedUser,
  ): Promise<UserResponseDto> {
    const existingUser = await this.findById(id);

    if (
      !existingUser ||
      (!this.isSuperAdministrator(requester) &&
        existingUser.clinicId !== requester.clinicId)
    ) {
      throw new NotFoundException('User not found.');
    }

    if (
      !this.isSuperAdministrator(requester) &&
      dto.clinicId &&
      dto.clinicId !== requester.clinicId
    ) {
      throw new ForbiddenException('You cannot move a user to another clinic.');
    }

    // Check duplicate email
    if (dto.email && dto.email !== existingUser.email) {
      const userWithEmail = await this.findByEmail(dto.email);

      if (userWithEmail) {
        throw new ConflictException('Email already exists.');
      }
    }

    // Validate clinic
    if (dto.clinicId) {
      const clinic = await this.findClinic(dto.clinicId);

      if (!clinic) {
        throw new NotFoundException('Clinic not found.');
      }
    }

    if (
      dto.clinicId &&
      dto.clinicId !== existingUser.clinicId &&
      !dto.roleIds
    ) {
      throw new ForbiddenException(
        'Assign roles from the destination clinic when moving a user.',
      );
    }

    // Validate roles
    if (dto.roleIds) {
      const roles = await this.findRoles(dto.roleIds);

      if (roles.length !== dto.roleIds.length) {
        throw new NotFoundException('One or more roles were not found.');
      }
      const targetClinicId = dto.clinicId ?? existingUser.clinicId;
      if (roles.some((role) => role.clinicId !== targetClinicId)) {
        throw new ForbiddenException(
          "All assigned roles must belong to the user's clinic.",
        );
      }
      if (
        !this.isSuperAdministrator(requester) &&
        roles.some((role) => this.isSuperAdminRoleCode(role.code))
      ) {
        throw new ForbiddenException(
          'Clinic administrators cannot assign the Super Administrator role.',
        );
      }
    }

    const updatedUser = await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: {
          id,
        },
        data: {
          firstName: dto.firstName,
          lastName: dto.lastName,
          email: dto.email,
          clinicId: dto.clinicId,
        },
      });

      if (dto.roleIds) {
        await tx.userRole.deleteMany({
          where: {
            userId: id,
          },
        });

        await tx.userRole.createMany({
          data: dto.roleIds.map((roleId) => ({
            userId: id,
            roleId,
          })),
        });
      }

      return tx.user.findUniqueOrThrow({
        where: {
          id,
        },
        include: {
          roles: {
            include: {
              role: true,
            },
          },
        },
      });
    });

    return UserMapper.toResponseDto(updatedUser);
  }

  async updateStatus(
    id: string,
    dto: UpdateUserStatusDto,
    requester: AuthenticatedUser,
  ): Promise<UserResponseDto> {
    const existingUser = await this.findById(id);

    if (
      !existingUser ||
      (!this.isSuperAdministrator(requester) &&
        existingUser.clinicId !== requester.clinicId)
    ) {
      throw new NotFoundException('User not found.');
    }

    const updatedUser = await this.prisma.user.update({
      where: {
        id,
      },
      data: {
        status: dto.status,
      },
      include: {
        roles: {
          include: {
            role: true,
          },
        },
      },
    });

    return UserMapper.toResponseDto(updatedUser);
  }
}
